﻿using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Text;

namespace Contososonpo
{
    public class TextPlainMediaTypeFormatter : BufferedMediaTypeFormatter

    {
        public TextPlainMediaTypeFormatter()
        {
            SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/plain"));
            SupportedEncodings.Add(new UTF8Encoding(encoderShouldEmitUTF8Identifier: false, throwOnInvalidBytes: true));
            SupportedEncodings.Add(new UnicodeEncoding(bigEndian: false, byteOrderMark: true, throwOnInvalidBytes: true));
        }

        public override bool CanReadType(Type type)
        {
            return type == typeof(string);
        }

        public override bool CanWriteType(Type type)
        {
            return type == typeof(string);
        }

        public override object ReadFromStream(Type type, Stream readStream, HttpContent content, IFormatterLogger formatterLogger, System.Threading.CancellationToken cancellationToken)
        {
            Encoding effectiveEncoding = SelectCharacterEncoding(content.Headers);
            using (StreamReader sReader = new StreamReader(readStream, effectiveEncoding))
            {
                return sReader.ReadToEnd();
            }
        }

        public override void WriteToStream(Type type, object value, Stream writeStream, HttpContent content, System.Threading.CancellationToken cancellationToken)
        {
            Encoding effectiveEncoding = SelectCharacterEncoding(content.Headers);
            using (StreamWriter sWriter = new StreamWriter(writeStream, effectiveEncoding))
            {
                sWriter.Write(value);
            }
        }

    }
}