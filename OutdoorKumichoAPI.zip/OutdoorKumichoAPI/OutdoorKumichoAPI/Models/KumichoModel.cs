namespace OutdoorKumichoAPI.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class KumichoModel : DbContext
    {
        public KumichoModel()
            : base("name=KumichoModel")
        {
        }

        public virtual DbSet<ActivityAttendees> ActivityAttendees { get; set; }
        public virtual DbSet<KumichoActivities> KumichoActivities { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ActivityAttendees>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<KumichoActivities>()
                .Property(e => e.Version)
                .IsFixedLength();
        }
    }
}
