﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Swashbuckle.Swagger.Annotations;
using Newtonsoft.Json;
using Microsoft.Azure;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace OutdoorKumichoAPI.Controllers
{
    public class CancelEventController : ApiController
    {
        [SwaggerOperation("GetAll")]
        public string Get()
        {
            return GetEventID();
        }

        private string GetEventID()
        {
            string result = "";
            //Service Bus接続文字列の取得
            string connectionString = CloudConfigurationManager.GetSetting("ServiceBusConnectionString");
            //Topic名の取得
            string TopicName = CloudConfigurationManager.GetSetting("CancelTopic");
            //Subscription名の取得
            string defaultsub = CloudConfigurationManager.GetSetting("DefaultSubscriptionName");
            string triggersub = CloudConfigurationManager.GetSetting("TriggerSubscriptionName");
            //NamespaceManagerインスタンスの作成
            NamespaceManager nsMan = NamespaceManager.CreateFromConnectionString(connectionString);
            //Topicの存在をチェックし、存在しない場合は新規作成
            if (nsMan.TopicExists(TopicName) == false)
                nsMan.CreateTopic(TopicName);
            //2種類のSubscriptionの存在をチェックし、存在しない場合は新規作成
            if (nsMan.SubscriptionExists(TopicName, defaultsub) == false)
                nsMan.CreateSubscription(TopicName, defaultsub);
            if (nsMan.SubscriptionExists(TopicName, triggersub) == false)
                nsMan.CreateSubscription(TopicName, triggersub);
            //Subscription Clientインスタンスの作成
            SubscriptionClient SClient = SubscriptionClient.CreateFromConnectionString(connectionString, TopicName, defaultsub);
            //Subscriptionからメッセージを受信
            BrokeredMessage msg = SClient.Receive(TimeSpan.FromSeconds(3));

            if (msg != null)
            {
                //メッセージを取得できた場合、本文を戻り値に設定
                result = msg.GetBody<string>();
                msg.Complete();
            }
            else
            {
                //取得できない場合、404を返す
                this.StatusCode(HttpStatusCode.NotFound);
                result = "0000";
            }
            return result;

        }
    }
}
