﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Web.Http;
using Microsoft.Azure.Mobile.Server;
using Microsoft.Azure.Mobile.Server.Authentication;
using Microsoft.Azure.Mobile.Server.Config;
using OutdoorKumichoMobile.DataObjects;
using OutdoorKumichoMobile.Models;
using Owin;

namespace OutdoorKumichoMobile
{
    public partial class Startup
    {
        public static void ConfigureMobileApp(IAppBuilder app)
        {
            HttpConfiguration config = new HttpConfiguration();

            new MobileAppConfiguration()
                .UseDefaultConfiguration()
                .ApplyTo(config);

            // Use Entity Framework Code First to create database tables based on your DbContext
            Database.SetInitializer(new MobileServiceInitializer());

            MobileAppSettingsDictionary settings = config.GetMobileAppSettingsProvider().GetMobileAppSettings();

            if (string.IsNullOrEmpty(settings.HostName))
            {
                app.UseAppServiceAuthentication(new AppServiceAuthenticationOptions
                {
                    // This middleware is intended to be used locally for debugging. By default, HostName will
                    // only have a value when running in an App Service application.
                    SigningKey = ConfigurationManager.AppSettings["SigningKey"],
                    ValidAudiences = new[] { ConfigurationManager.AppSettings["ValidAudience"] },
                    ValidIssuers = new[] { ConfigurationManager.AppSettings["ValidIssuer"] },
                    TokenHandler = config.GetAppServiceTokenHandler()
                });
            }

            app.UseWebApi(config);
        }
    }

    public class MobileServiceInitializer : CreateDatabaseIfNotExists<OutdoorKumichoMobileContext>
    {
        protected override void Seed(OutdoorKumichoMobileContext context)
        {
            List<KumichoActivity> KumichoActivitys = new List<KumichoActivity>
            {
                new KumichoActivity { Id = Guid.NewGuid().ToString(),EventID=Guid.NewGuid().ToString(), Title = "大山(阿夫利山)山頂アタック",Area="神奈川県",ActivityType="登山", ActualAttendees=0,  PictureURL="https://tasakaijpeast.blob.core.windows.net/demopics/oyama.jpg",MaxAttendees=20,MinAttendees=2, ActivityLevel="中級", Description = "新緑に囲まれた、阿夫利山としても知られる大山の山頂を目指します。往路は阿夫利神社下社までケーブルカーを使用するので、数回の登山経験があれば登頂は難しくないでしょう。大山登頂後はヤビツ峠に降り、バスで下山します。",Schedule = "2016年5月26日 8:30", IsCanceled = false,IsComitted=false },
                new KumichoActivity { Id = Guid.NewGuid().ToString(),EventID=Guid.NewGuid().ToString(), Title = "高尾山初心者向け登山",Area="東京都",ActivityType="ハイキング",ActualAttendees=0, PictureURL="https://tasakaijpeast.blob.core.windows.net/demopics/takaosan.jpg",MaxAttendees=20,MinAttendees=2,ActivityLevel="初級",Description = "ミシュラングリーンガイドで三ツ星を獲得した高尾山のハイキングです。初心者に優しいコースを通るため、登山未経験者でもOKです。下山はケーブルカーで楽々下山。",Schedule ="2016年5月26日 10:00", IsCanceled = false,IsComitted=false },
            };

            foreach (KumichoActivity KumichoActivity in KumichoActivitys)
            {
                context.Set<KumichoActivity>().Add(KumichoActivity);
            }

            List<ActivityAttendees> ActivityAttendees = new List<ActivityAttendees>
            {
                new ActivityAttendees { Id = Guid.NewGuid().ToString(), EventID =Guid.NewGuid().ToString(), FirstName = "達明", FamilyName="酒井",TwitterID="tatsuakisakai",  IsCanceled = false,IsAttended=false },
                new ActivityAttendees { Id = Guid.NewGuid().ToString(), EventID =Guid.NewGuid().ToString(), FirstName = "びる", FamilyName="るい",TwitterID="louisville0919",  IsCanceled = false,IsAttended=false  },
            };

            foreach (ActivityAttendees ActivityAttendee in ActivityAttendees)
            {
                context.Set<ActivityAttendees>().Add(ActivityAttendee);
            }
            base.Seed(context);
        }
    }
}

