﻿using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.OData;
using Microsoft.Azure.Mobile.Server;
using OutdoorKumichoMobile.DataObjects;
using OutdoorKumichoMobile.Models;

namespace OutdoorKumichoMobile.Controllers
{
    [AllowAnonymous]
    public class KumichoActivityController : TableController<KumichoActivity>
    {
        protected override void Initialize(HttpControllerContext controllerContext)
        {
            base.Initialize(controllerContext);
            OutdoorKumichoMobileContext context = new OutdoorKumichoMobileContext();
            DomainManager = new EntityDomainManager<KumichoActivity>(context, Request);
        }

        // GET tables/KumichoActivity
        public IQueryable<KumichoActivity> GetAllKumichoActivity()
        {
            return Query(); 
        }

        // GET tables/KumichoActivity/48D68C86-6EA6-4C25-AA33-223FC9A27959
        public SingleResult<KumichoActivity> GetKumichoActivity(string id)
        {
            return Lookup(id);
        }

        // PATCH tables/KumichoActivity/48D68C86-6EA6-4C25-AA33-223FC9A27959
        public Task<KumichoActivity> PatchKumichoActivity(string id, Delta<KumichoActivity> patch)
        {
             return UpdateAsync(id, patch);
        }

        // POST tables/KumichoActivity
        public async Task<IHttpActionResult> PostKumichoActivity(KumichoActivity item)
        {
            KumichoActivity current = await InsertAsync(item);
            return CreatedAtRoute("Tables", new { id = current.Id }, current);
        }

        // DELETE tables/KumichoActivity/48D68C86-6EA6-4C25-AA33-223FC9A27959
        public Task DeleteKumichoActivity(string id)
        {
             return DeleteAsync(id);
        }
    }
}
