﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Microsoft.Azure;
using Microsoft.Azure.Mobile.Server.Config;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
namespace OutdoorKumichoMobile.Controllers
{
    [MobileAppController,AllowAnonymous]
    public class ConfirmEventController : ApiController
    {
        // GET: api/ConfirmEvent/5
        public string Get(string id)
        {
            return SendTopicMessage(id);
        }

        private static string SendTopicMessage(string id)
        {
            //Service Bus接続文字列
            string connectionString = CloudConfigurationManager.GetSetting("ServiceBusConnectionString");
            //Topic名
            string TopicName = CloudConfigurationManager.GetSetting("CommitTopic");
            //NamespaceManagerの生成
            NamespaceManager nsMan = NamespaceManager.CreateFromConnectionString(connectionString);
            //TopicおよびSubscriptionの存在をチェックし、存在しない場合は新規作成
            if (nsMan.TopicExists(TopicName) == false)
                nsMan.CreateTopic(TopicName);
            if (nsMan.SubscriptionExists(TopicName, "confirm") == false)
                nsMan.CreateSubscription(TopicName, "confirm");
            if (nsMan.SubscriptionExists(TopicName, "trigger") == false)
                nsMan.CreateSubscription(TopicName, "trigger");
            //Topicクライアントの作成
            TopicClient TClient = TopicClient.CreateFromConnectionString(connectionString, TopicName);
            //Topicにメッセージを送信
            TClient.Send(new BrokeredMessage(id));
            //TopicClientをClose
            TClient.Close();
            return id;
        }
    }
}
